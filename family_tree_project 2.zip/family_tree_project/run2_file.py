from family_tree import FamilyTree


def main() -> None:
    tree = FamilyTree()
    try:
        tree.load_from_json('data/family_tree_63.json')
    except Exception:
        print('Не удалось загрузить данные из data/family_tree_63.json')
        return

    name = input('Введите имя участника для аналитического запуска: ').strip()
    if name not in tree.members:
        print('Человек не найден в данных.')
        return

    print(f'Итеративный обход DFS от {name}:')
    path = tree.iterative_dfs_with_stack(name)
    for member in path:
        print(f'- {member.name} ({member.birth_date_str or "нет даты"})')

    print(f'\nПредки для {name}:')
    ancestors = tree.find_ancestors_recursive(name)
    if ancestors:
        for ancestor in ancestors:
            print(f'- {ancestor.name} ({ancestor.birth_date_str or "нет даты"})')
    else:
        print('  не найдены')

    print('\nСортировка по дате рождения:')
    tree.sort_by_birth_date()
    for member in tree.members.values():
        print(f'- {member.name} ({member.birth_date_str or "нет даты"})')


if __name__ == '__main__':
    main()
