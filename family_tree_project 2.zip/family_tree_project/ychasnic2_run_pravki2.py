from family_tree import FamilyTree


def get_ancestors(tree, name):
    start = tree.members.get(name)

    if not start:
        return set()

    return set(tree.find_ancestors_recursive(name))


def main():
    tree = FamilyTree()

    tree.load_from_json("data/family_tree_63.json")

    first_name = input("Введите первого человека: ")
    second_name = input("Введите второго человека: ")

    if first_name not in tree.members:
        print("Первый человек не найден")
        return

    if second_name not in tree.members:
        print("Второй человек не найден")
        return

    ancestors1 = get_ancestors(tree, first_name)
    ancestors2 = get_ancestors(tree, second_name)

    common = ancestors1 & ancestors2

    print("\nОбщие предки:")

    if not common:
        print("Общих предков нет")
        return

    for person in common:
        print(person)


if __name__ == "__main__":
    main()