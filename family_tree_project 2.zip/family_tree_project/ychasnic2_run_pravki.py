from family_tree import FamilyTree


def count_descendants(tree, name):
    start = tree.members.get(name)

    if not start:
        return 0

    stack = [start]
    visited = set()
    count = 0

    while stack:
        node = stack.pop()

        for child in node.children:
            if child.name not in visited:
                visited.add(child.name)
                stack.append(child)
                count += 1

    return count


def main():
    tree = FamilyTree()
    tree.load_from_json("data/family_tree_63.json")

    name = input("Введите человека: ")

    if name not in tree.members:
        print("Человек не найден")
        return

    result = count_descendants(tree, name)

    print(f"Количество потомков: {result}")


if __name__ == "__main__":
    main()