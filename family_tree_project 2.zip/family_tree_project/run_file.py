import matplotlib.pyplot as plt
from typing import List, Optional, Tuple

from family_tree import FamilyTree, FamilyMember


def infer_gender(name: str) -> str:
    """Попыточно определяет пол по имени для цветовой маркировки."""
    first_name = name.split()[0].lower()
    female_suffixes = (
        "а", "я", "на", "ка", "та", "иха", "ея", "ина", "ева",
        "a", "ya", "ya", "na", "ka", "ta", "ikha", "eya", "ina", "eva",
        "ova", "ova"
    )
    if first_name.endswith(female_suffixes):
        return "female"
    return "male"


def format_years(member: Optional[FamilyMember]) -> str:
    if member is None:
        return "—"
    if member.birth_date:
        return f"{member.birth_date.year}–"
    if member.birth_date_str:
        try:
            return str(int(member.birth_date_str[:4])) + "–"
        except Exception:
            return "—"
    return "—"


def label_text(member: Optional[FamilyMember]) -> str:
    if member is None:
        return "—\n—"
    return f"{member.name}\n{format_years(member)}"


def choose_parent_roles(parents: List[FamilyMember]) -> Tuple[Optional[FamilyMember], Optional[FamilyMember]]:
    father: Optional[FamilyMember] = None
    mother: Optional[FamilyMember] = None
    seen_names = set()
    unique_parents: List[FamilyMember] = []
    for parent in parents:
        if parent.name in seen_names:
            continue
        seen_names.add(parent.name)
        unique_parents.append(parent)

    for parent in unique_parents:
        gender = infer_gender(parent.name)
        if gender == "male" and father is None:
            father = parent
        elif gender == "female" and mother is None:
            mother = parent

    for parent in unique_parents:
        if parent is father or parent is mother:
            continue
        if father is None:
            father = parent
        elif mother is None:
            mother = parent
        else:
            break

    return father, mother


def draw_family_diagram(child: Optional[FamilyMember],
                        father: Optional[FamilyMember],
                        mother: Optional[FamilyMember],
                        paternal_grandfather: Optional[FamilyMember],
                        paternal_grandmother: Optional[FamilyMember],
                        maternal_grandfather: Optional[FamilyMember],
                        maternal_grandmother: Optional[FamilyMember]) -> None:
    fig, ax = plt.subplots(figsize=(10, 7))
    ax.set_xlim(-2.5, 2.5)
    ax.set_ylim(-0.5, 2.5)

    positions = {
        "child": ((0.0, 0.0), child),
        "father": ((-0.9, 1.0), father),
        "mother": ((0.9, 1.0), mother),
        "paternal_grandfather": ((-1.7, 2.0), paternal_grandfather),
        "paternal_grandmother": ((-0.9, 2.0), paternal_grandmother),
        "maternal_grandfather": ((0.9, 2.0), maternal_grandfather),
        "maternal_grandmother": ((1.7, 2.0), maternal_grandmother),
    }

    lines = [
        ("child", "father"),
        ("child", "mother"),
        ("father", "paternal_grandfather"),
        ("father", "paternal_grandmother"),
        ("mother", "maternal_grandfather"),
        ("mother", "maternal_grandmother"),
    ]
    for source, target in lines:
        start, _ = positions[source]
        end, _ = positions[target]
        ax.plot([start[0], end[0]], [start[1], end[1]], color="black", linewidth=1.5, zorder=1)

    def node_color(member: Optional[FamilyMember]) -> str:
        if member is None:
            return "black"
        return "red" if infer_gender(member.name) == "female" else "blue"

    for position, member in positions.values():
        x, y = position
        color = node_color(member)
        circle = plt.Circle((x, y), 0.18, color=color, zorder=2)
        ax.add_patch(circle)
        ax.text(x, y - 0.28, label_text(member), ha="center", va="top", fontsize=10, family="sans-serif")

    ax.axis("off")
    title = f"Генеалогическая схема для {child.name if child else '—'}"
    ax.set_title(title, fontsize=14)
    plt.tight_layout()
    plt.savefig("family_tree_diagram.png", dpi=150, bbox_inches="tight")
    print("Схема сохранена в family_tree_diagram.png")
    plt.show()


def main() -> None:
    tree = FamilyTree()
    tree.load_from_json("data/family_tree_63.json")

    name = input("Введите имя человека, от которого вести отсчет: ").strip()
    print(f"Выбран человек: {name}")

    child = tree.members.get(name)
    if child is None:
        print("Человек не найден в данных.")
        return

    parent_list = tree.get_parents(name)
    father, mother = choose_parent_roles(parent_list)

    paternal_grandparents = choose_parent_roles(tree.get_parents(father.name) if father else [])
    maternal_grandparents = choose_parent_roles(tree.get_parents(mother.name) if mother else [])

    draw_family_diagram(
        child=child,
        father=father,
        mother=mother,
        paternal_grandfather=paternal_grandparents[0],
        paternal_grandmother=paternal_grandparents[1],
        maternal_grandfather=maternal_grandparents[0],
        maternal_grandmother=maternal_grandparents[1],
    )


if __name__ == "__main__":
    main()
