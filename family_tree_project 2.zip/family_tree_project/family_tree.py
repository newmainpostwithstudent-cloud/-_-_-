"""
family_tree.py

Модуль описывает простое семейное дерево.

Записи читаются из JSON или CSV. Каждый участник хранит имя,
дату рождения и список детей. Затем связи строятся так, чтобы
дерево можно было обойти рекурсивно.
"""
from __future__ import annotations

import csv
import json
from datetime import datetime
from typing import Dict, List, Optional, Any


class FamilyMember:
    """
    Узел семейного дерева.

    Хранит имя, текст даты рождения и, если возможно,
    распаршенную дату. Связь между людьми проходит через детей,
    поэтому каждый узел знает своих потомков.
    """

    def __init__(self, name: str, birth_date: Optional[str] = None) -> None:
        """Создаёт участника и пробует распарсить дату."""
        self.name: str = name
        self.birth_date_str: Optional[str] = birth_date
        self.birth_date: Optional[datetime] = None
        if birth_date:
            try:
                self.birth_date = datetime.strptime(birth_date, "%Y-%m-%d")
            except ValueError:
                # Если строка не в формате YYYY-MM-DD, просто сохраняем её как текст
                self.birth_date = None

        # Дети этого участника
        self.children: List[FamilyMember] = []

    def add_child(self, child: FamilyMember) -> None:
        """Добавляет ребёнка в список детей и сохраняет связь."""
        self.children.append(child)

    def __repr__(self) -> str:
        return f"FamilyMember(name={self.name!r}, birth_date={self.birth_date_str!r})"


class FamilyTree:
    """
    Хранит всех участников и корни.

    Первый проход создаёт узлы по именам, второй проход строит связи
    родитель-ребёнок. Корни нужны, чтобы начать обход с людей без родителя.
    """

    def __init__(self) -> None:
        # Словарь name -> FamilyMember
        self.members: Dict[str, FamilyMember] = {}
        # Список корней (у кого нет родителя в наборе данных)
        self.roots: List[FamilyMember] = []
        # Словарь child_name -> список родителей
        self.parents: Dict[str, List[FamilyMember]] = {}


# загрузка данных
    def load_from_json(self, path: str) -> None:
        """Открывает JSON-файл и передаёт записи в сборщик дерева."""
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("JSON должен содержать список объектов")
        # Собираем и строим дерево
        self.build_tree_from_flat_list(data)

    def load_from_csv(self, path: str) -> None:
        """Открывает CSV и нормализует строки родителей перед сборкой дерева."""
        rows: List[Dict[str, Any]] = []
        with open(path, newline="", encoding="utf-8") as csvfile:
            reader = csv.DictReader(csvfile)
            for r in reader:
                # Нормализуем parents_list, если он задан как строка с ';'
                if "parents_list" in r and r["parents_list"]:
                    # Преобразуем строку в список
                    parents = [p.strip() for p in r["parents_list"].split(";") if p.strip()]
                    r["parents_list"] = parents
                rows.append(r)
        self.build_tree_from_flat_list(rows)

    # Генератор (бета-тест)
    def generate_mock_data(self) -> List[Dict[str, Any]]:
        """Создаёт набор тестовых записей и сразу строит дерево."""
        flat = [
            {"name": "Ivan Petrov", "parent_name": None, "birth_date": "1945-05-10"},
            {"name": "Elena Ivanova", "parent_name": None, "birth_date": "1947-08-20"},

            {"name": "Petr Ivanov", "parent_name": "Ivan Petrov", "birth_date": "1970-03-15"},
            {"name": "Anna Petrova", "parent_name": "Ivan Petrov", "birth_date": "1973-11-02"},

            {"name": "Sergey Petrov", "parent_name": "Petr Ivanov", "birth_date": "1995-07-07"},
            {"name": "Marina Petrova", "parent_name": "Anna Petrova", "birth_date": "1998-12-12"},

            {"name": "Olga Sergeeva", "parent_name": "Sergey Petrov", "birth_date": "2020-01-01"},
        ]
        flat.append({"name": "Nikolai Sidorov", "parent_name": None, "birth_date": "1950-09-09"})
        flat.append({"name": "Irina Nikolaeva", "parent_name": "Nikolai Sidorov", "birth_date": "1980-06-06"})

        self.build_tree_from_flat_list(flat)
        return flat

    # Построение дерева (рекурсивно) 
    def build_tree_from_flat_list(self, flat_list: List[Dict[str, Any]]) -> None:
        """Строит иерархию родитель-ребёнок из списка записей."""
        self.members.clear()
        self.roots.clear()
        self.parents.clear()

        # Первый проход: создаём узел для каждого уникального имени.
        # Это даёт быстрый доступ к участникам по имени при связывании.
        for rec in flat_list:
            name = rec.get("name")
            if not name:
                continue
            birth = rec.get("birth_date")
            if name not in self.members:
                self.members[name] = FamilyMember(name=name, birth_date=birth)
            else:
                # Обновим дату рождения, если она есть
                if birth:
                    self.members[name].birth_date_str = birth

        parent_index: Dict[Optional[str], List[str]] = {}
        for rec in flat_list:
            name = rec.get("name")
            if not name:
                continue

            # Поддерживаем два варианта обозначения родителей
            parents = []
            if rec.get("parents_list"):
                parents = rec.get("parents_list") or []
            elif "parent_name" in rec:
                p = rec.get("parent_name")
                # Нормализуем пустые значения в None
                parents = [p] if p else [None]
            else:
                parents = [None]

            for p in parents:
                parent_index.setdefault(p, []).append(name)

        # 3) Рекурсивная функция прикрепления детей к заданному родителю
        def attach_children(parent_name: Optional[str], parent_node: Optional[FamilyMember], visited: set[str]) -> None:
            """Вставляет в дерево всех детей данного родителя."""
            children_names = parent_index.get(parent_name, [])
            for child_name in children_names:
                if child_name in visited:
                    # Защита от циклических или самоссылающихся данных.
                    continue
                child_node = self.members.get(child_name)
                if not child_node:
                    continue
                if parent_node is not None:
                    if child_name == parent_name:
                        continue
                    parent_node.add_child(child_node)
                    self.parents.setdefault(child_name, []).append(parent_node)
                else:
                    self.roots.append(child_node)

                attach_children(child_name, child_node, visited | {child_name})

        # Запускаем рекурсию с parent_name == None
        attach_children(None, None, set())

    # Обходы дерева (рекурсивно)
    def _print_node(self, node: FamilyMember, depth: int) -> None:
        """Печатает узел с отступом по уровню."""
        indent = "    " * depth
        birth = f" ({node.birth_date_str})" if node.birth_date_str else ""
        print(f"{indent}- {node.name}{birth}")

    def preorder(self, node: Optional[FamilyMember] = None, depth: int = 0) -> None:
        """Печатает текущего человека, затем всех его детей рекурсивно."""
        if node is None:
            for r in self.roots:
                self.preorder(r, depth=0)
            return

        self._print_node(node, depth)
        for c in node.children:
            self.preorder(c, depth + 1)

    def inorder(self, node: Optional[FamilyMember] = None, depth: int = 0) -> None:
        """Печатает часть детей, потом родителя, потом остаток детей."""
        if node is None:
            for r in self.roots:
                self.inorder(r, depth=0)
            return

        n = len(node.children)
        mid = n // 2
        for c in node.children[:mid]:
            self.inorder(c, depth + 1)

        self._print_node(node, depth)
        for c in node.children[mid:]:
            self.inorder(c, depth + 1)

    def postorder(self, node: Optional[FamilyMember] = None, depth: int = 0) -> None:
        """Печатает сначала всех детей, потом родителя."""
        if node is None:
            for r in self.roots:
                self.postorder(r, depth=0)
            return

        for c in node.children:
            self.postorder(c, depth + 1)
        self._print_node(node, depth)

    # Методы второго участника
    def find_ancestors_recursive(self, name: str) -> List[FamilyMember]:
        """Рекурсивно ищет предков участника по имени.

        Возвращает список предков от ближайшего к более дальнему. Если участник
        не найден или у него нет предков в дереве, возвращается пустой список.
        """
        start = self.members.get(name)
        if start is None:
            return []

        ancestors: List[FamilyMember] = []
        visited: set[str] = set()

        def collect_parents(node: FamilyMember) -> None:
            for parent in self.parents.get(node.name, []):
                if parent.name in visited:
                    continue
                visited.add(parent.name)
                ancestors.append(parent)
                collect_parents(parent)

        collect_parents(start)
        return ancestors

    def sort_by_birth_date(self) -> None:
        """Сортирует участников дерева по дате рождения.

        Сортировка применяется к общему словарю участников, к корням дерева и к
        спискам детей каждого участника. Участники без корректной даты рождения
        помещаются после участников с известной датой; при равных датах порядок
        дополнительно определяется по имени.
        """
        def sort_key(member: FamilyMember) -> tuple:
            return (member.birth_date is None, member.birth_date or datetime.max, member.name)

        self.members = dict(sorted(self.members.items(), key=lambda item: sort_key(item[1])))
        self.roots.sort(key=sort_key)
        for member in self.members.values():
            member.children.sort(key=sort_key)

    def get_parents(self, name: str) -> List[FamilyMember]:
        """Возвращает список известных родителей участника."""
        return self.parents.get(name, [])

    def iterative_dfs_with_stack(self, start_name: Optional[str] = None) -> List[FamilyMember]:
        """Выполняет итеративный DFS с использованием стека.

        Если передано имя, обход начинается с этого участника. Если имя не
        передано, обход начинается со всех корней дерева. Метод возвращает
        список узлов в порядке посещения. Дети кладутся в стек в обратном
        порядке, чтобы итоговый обход совпадал с привычным pre-order.
        """
        if start_name is not None:
            start_node = self.members.get(start_name)
            if start_node is None:
                return []
            stack: List[FamilyMember] = [start_node]
        else:
            stack = list(reversed(self.roots))

        visited = set()
        result: List[FamilyMember] = []

        while stack:
            node = stack.pop()
            if node.name in visited:
                continue

            visited.add(node.name)
            result.append(node)

            # reversed нужен из-за LIFO-логики стека: первый ребёнок будет посещён первым.
            for child in reversed(node.children):
                if child.name not in visited:
                    stack.append(child)

        return result
