from family_tree import FamilyTree


def main() -> None:
    tree = FamilyTree()
    try:
        tree.load_from_json('data/family_tree_63.json')
    except Exception:
        print('Не удалось загрузить данные из data/family_tree_63.json')
        return

    print('Сортировка по дате рождения:')
    tree.sort_by_birth_date()
    for member in tree.members.values():
        print(f'- {member.name} ({member.birth_date_str or "нет даты"})')

    print('\nИтеративный обход DFS от корней:')
    path = tree.iterative_dfs_with_stack()
    for member in path:
        print(f'- {member.name} ({member.birth_date_str or "нет даты"})')

    person = 'Иван Петров'
    ancestors = tree.find_ancestors_recursive(person)
    print(f'\nПредки для {person}:')
    if ancestors:
        for ancestor in ancestors:
            print(f'- {ancestor.name} ({ancestor.birth_date_str or "нет даты"})')
    else:
        print('  не найдены')


if __name__ == '__main__':
    main()
